#include "SB02.h"

int factorial(int n) {
    return 0;
}

