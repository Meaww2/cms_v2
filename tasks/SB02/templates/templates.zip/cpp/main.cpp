#include <iostream>
#include "SB02.h"

using namespace std;

int main() {
    int n;

    cin >> n
    cout << factorial(n) << endl;

    return 0;
}