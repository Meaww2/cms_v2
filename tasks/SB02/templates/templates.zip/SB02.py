#!/usr/bin/env python3
# @Author: kk
# @Date:   2024-04-13 00:06:43
# @Last Modified by:   kk
# @Last Modified time: 2024-04-15 14:41:00

def factorial(n):
    return 0


if __name__ == '__main__':
    print(factorial(int(input())))
