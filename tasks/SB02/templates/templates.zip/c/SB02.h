#ifndef SB02_H
#define SB02_H

int factorial(int n);


#endif // SB02_H
