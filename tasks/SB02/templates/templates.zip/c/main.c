#include <stdio.h>
#include "SB02.h"

int main() {
    int n;

    scanf("%d", &n);
    printf("%d\n", factorial(n));

    return 0;
}